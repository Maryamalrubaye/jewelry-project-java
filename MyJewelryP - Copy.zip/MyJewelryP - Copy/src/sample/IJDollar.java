package sample;

public interface IJDollar {

    public abstract double dollar(int caliber, double ONS, double grams, double wages);
}
