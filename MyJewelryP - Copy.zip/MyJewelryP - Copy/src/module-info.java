module MyJWFxProject {
    requires javafx.fxml;
    requires javafx.controls;
    requires java.desktop;
    requires javafx.web;
    requires itextpdf;
    opens sample;
}